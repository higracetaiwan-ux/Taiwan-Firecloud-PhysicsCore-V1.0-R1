import fs from 'node:fs';
import {evaluateIceOptics} from '../windy/iceOpticsEvaluator.mjs';
const lut=JSON.parse(fs.readFileSync(new URL('../ice_optics_lut_v1.json', import.meta.url),'utf8')).records;
const v=JSON.parse(fs.readFileSync(new URL('./reference_vectors.json', import.meta.url),'utf8'));
const close=(a,b,t=1e-10)=>a===b || (Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<=t*Math.max(1,Math.abs(a),Math.abs(b)));
function eq(a,b,path='root') { if (typeof a==='number'||typeof b==='number') {if(!close(a,b)) throw new Error(`${path}: ${a} != ${b}`);return;} if(a===null||b===null||typeof a!=='object'||typeof b!=='object'){if(a!==b)throw new Error(`${path}: ${a} != ${b}`);return;} for(const k of new Set([...Object.keys(a),...Object.keys(b)]))eq(a[k],b[k],`${path}.${k}`); }
for(const x of v.vectors){const got=evaluateIceOptics(x.input,lut);eq(got,x.expected,x.case_id);}
console.log(`PASS ${v.vectors.length} vectors`);
